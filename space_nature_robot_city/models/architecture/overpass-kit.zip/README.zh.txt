双层跨线立交组件包 / 风格评审原型

解压后将六个 .pb 作为独立原生实体导入；ZIP 不是单个 Space 模型。
按照 interchange-layout.json 放置 11 个组件实例。position 为模型创作原点相对于组合原点的偏移，rotationY 单位为弧度。
自动导入调用 buildFromSlot(slot, origin)；旋转实例时 position = origin + rotated(localCenter)，quaternion 为 Y 轴旋转。
手工工具显示实体中心时，需将原点坐标加上旋转后的包围盒中心，不能直接把布局原点作为中心坐标。
上层道路东西向，下层道路南北向。每端四段引道，另一端旋转 180 度；下层延长路位于 Z = ±12 米。
全长 108 米；桥下几何净空 4.375 米；本组不包含上下层转弯匝道。
基础向下延伸 3 米。落地端点与土方、载具驾驶、机器人施工仍待风格确认后测试。
